//
//  main.cpp
//  remove double
//
//  Created by David Qian on 2021/3/2.
//
#include <cstring>
#include <iostream>
#include <cstdlib>
#include <cstddef>

using namespace std;

string remove_dou(string str)
{
    
    int i,j;
    string tem_str;
    tem_str.append(str,0,1);                             //可以替代为：tem_str=tem_str+str[0];
//    tem_str.append(str，0，1)——->在tem_str后面加入字符串str，0:代表起始点str[0]，1:代表插入多少字符
//    tem_str.append(5,'i')---->  在tem_str后面加入字符‘i'，5代表加入5个’i‘
    
    for(i=1;i<str.length();i++)
    {

        for(j=0;j<tem_str.length();j++)
        {
            
            if(str[i]==tem_str[j]/* &&str[i]!=' ' */)
                break;
        }
        if(j==tem_str.length())//把tem_str全搜索一遍，和str[i]做比较
                               //如果没有和str[i]一样的，break就不会触发
                               //那么判断成立
        tem_str.append(str,i,1);                         //可以替代为：tem_str=tem_str+str[i];
                                //判断成立后，把str[i]（没有重复的字符）加入tem_str中
                                //然后开始str[i+1]重新上面的循环
    
    }
    return tem_str;
}


int main()
{
    
    string str;
    cout<<"请输入一字符串";
    
    getline(cin,str);//防止遇见空格就结束
    
    string new_str=remove_dou(str);    //接收string函数的返回值
    cout<<"去重复后的字符串："<<new_str<<endl;
    return 0;
    
}
