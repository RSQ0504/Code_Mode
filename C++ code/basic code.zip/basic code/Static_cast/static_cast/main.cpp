//
//  main.cpp
//  static_cast
//
//  Created by David Qian on 2021/3/16.
//

#include <iostream>
#include <string.h>
using namespace std;
int main(){
    int a=5,b=3;
    cout<<"static_cast<float>(a)/b="<<static_cast<float>(a)/b<<endl;
    cout<<"static_cast<float>(a)/static_cast<float>(b)="<<static_cast<float>(a)/static_cast<float>(b)<<endl;
    cout<<"static_cast<float>(a/b)="<<static_cast<float>(a/b)<<endl;
    cout<<"a="<<a<<endl;
    cout<<"b="<<b<<endl;
    return 0;
}
//static_cast用于强制类型转换
//上面可以看到int类型被转化为float类型
