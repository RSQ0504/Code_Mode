//
//  function.h
//  Dynamic arrays
//
//  Created by David Qian on 2021/3/16.
//

#include <string>
#include <iostream>
using namespace std;

//与整型有关的函数（int)
void exchange(int &a,int &b)//单个int类型通过自定义函数变化main函数里面值的办法
{
    int tempt;
    tempt=a;
    a=b;
    b=tempt;
    return;
}//单个int类型通过自定义函数变化main函数里面值的办法


//=======================================================================================
//=======================================================================================

//与一维数组有关的函数(a[i])


void cinarr(int *arr,int n)//数组通过自定义函数，改变main函数里面值的办法，用指针当作自定义函数的输入量
{
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    return;
};

int *arrofprint(int n)//作用和上一个函数一样的事，它赋值的方式是通过指针函数
{
    int *p=new int[n];
    for(int i=0;i<n;i++){
        cin>>p[i];
    }
    return p;
}

void coutarr(int *arr,int n){
    for(int i=0;i<n;i++){
        cout<<arr[i]<<endl;
    }
    return;
}//数组通过自定义函数变化main函数里面值的办法


//=======================================================================================
//=======================================================================================

//与二维数组有关的函数(a[i][j])


float **creatmatatrix(const int R,const int c){
    float **p=new float*[R];
    for(int i=0;i<R;i++){
        p[i]=new float[c];
    }
    return p;
}

void populateMatrix(float **M,const int R,const int c){
    for(int i=0;i<R;i++){
        for(int j=0;j<c;j++){
            M[i][j]=rand()%6+1;
        }
    }
    return;
}


void printMatrix(float **M,const int R,const int c){
    for(int i=0;i<R;i++){
        for(int j=0;j<c;j++){
            cout<<M[i][j]<<" ";
        }
        cout<<endl;
    }
    return;
}
