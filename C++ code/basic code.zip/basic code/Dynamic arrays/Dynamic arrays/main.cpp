//
//  main.cpp
//  Dynamic arrays
//
//  Created by David Qian on 2021/3/16.
//

#include <string>
#include <iostream>
#include "function.h"
using namespace std;



int main(){
    
    //与整型有关(int)
    
    int a=1,b=2;
    exchange(a,b);//单个int类型通过自定义函数变化main函数里面值的办法
    cout<<a<<"   "<<b<<endl;
    

//=======================================================================================
//=======================================================================================
    
    //与一维数组有关(a[i])
    
    
    int n;
    cout<<"enter the number"<<endl;
    cin>>n;
    
    
    //用来测试数组通过自定义函数，改变main函数里面值的办法，用指针当作自定义函数的输入量
    int *arr=new int[n];//创建动态数组的办法
    cinarr(arr,n);//数组通过自定义函数变化main函数里面值的办法
    coutarr(arr,n);
    
    
    //用来测试指针函数的，通过将整个自定义函数设置成一个指针类型
    int *p=arrofprint(n);//必须要这样
    for(int i=0;i<n;i++){
        cout<<p[i]<<endl;
    }
    /*
     cout<<arrofprint(n)[0];
     cout<<arrofprint(n)[1];
     cout<<arrofprint(n)[2];
     这是行不通的
     */
    

//======================================================================================
//=======================================================================================
    
    //与二维数组有关(a[i][j])
    
   
    float **M;//二维动态数组
    M=new float*[4];
    for(int i=0;i<4;i++){
        M[i]=new float[5];
    }
    //创造了一个4*5的二维数组，也就是a[4][5];
    
    
    //二维数组自定义函数变量的调用；
    int rowsize,colsize;
    cin>>rowsize;
    cin>>colsize;
    float **N=creatmatatrix(rowsize,colsize);//构建二维数组:N[rowsize][colsize];
    populateMatrix(N,rowsize,colsize);//二维数组:N[rowsize][colsize]赋值；
    printMatrix(N,rowsize,colsize);//二维数组:N[rowsize][colsize]打印；
    

//======================================================================================
//=======================================================================================
        
    
    delete[] arr;//一定要记得delete；
    
    for(int i=0;i<4;i++){
        delete[] M[i];
    }
    delete[] M;//二维数组和普通数组delete方式不一样
    return 0;
}
